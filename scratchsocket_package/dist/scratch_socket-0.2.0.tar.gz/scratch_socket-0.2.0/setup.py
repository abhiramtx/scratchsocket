# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['scratch_socket']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.22.2,<2.0.0',
 'replit>=3.2.4,<4.0.0',
 'requests>=2.28.1,<3.0.0',
 'websocket>=0.2.1,<0.3.0']

setup_kwargs = {
    'name': 'scratch-socket',
    'version': '0.2.0',
    'description': '',
    'long_description': '# Scratch Socket\n\nThis is a simple example Scratch Socket package. Usage details are as below\n\n1. Step1\n2. Step2\n3. Step3\n4. Step4',
    'author': 'Abhiram V',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.0,<3.9',
}


setup(**setup_kwargs)
