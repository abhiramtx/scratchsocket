# Scratch Socket

This is a simple example Scratch Socket package. Usage details are as below

1. Step1
2. Step2
3. Step3
4. 